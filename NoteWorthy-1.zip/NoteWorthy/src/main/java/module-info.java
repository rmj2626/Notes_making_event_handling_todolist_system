module com.example.noteworthy {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires ojdbc6;
    requires javafx.graphics;


    opens com.example.noteworthy to javafx.fxml;
    exports com.example.noteworthy;
}